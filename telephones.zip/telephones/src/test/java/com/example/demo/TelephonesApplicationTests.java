package com.example.demo;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entities.Marque;
import com.example.demo.entities.Telephone;
import com.example.demo.repos.MarqueRepository;

@SpringBootTest
class TelephonesApplicationTests {
	
	@Autowired
	private MarqueRepository marqueRepository;
	
	@Test
	public void testCreateMarque() {
		Marque marque = new Marque("Galaxy S22 ultra", 3999.0, new Date());
		marqueRepository.save(marque);
	}
	
	@Test
	public void testFindMarque()
	{
		Marque m = marqueRepository.findById(1L).get();
		System.out.println(m);
	}
	
	@Test
	public void testUpdateMarque()
	{
		Marque m = marqueRepository.findById(1L).get();
		m.setPrixMarque(600.0);
		marqueRepository.save(m);
		System.out.println(m);
	}
	
	@Test
	public void testDeleteMarque()
	{
		marqueRepository.deleteById(3L);
	}
	
	
	@Test
	public void testFindAllMarques()
	{
		List<Marque> marques = marqueRepository.findAll(); 
		
		for (Marque m:marques)
			System.out.println(m);
	}
	
	
	
	@Test
	public void testFindMarqueByNom()
	{
		List<Marque> marques = marqueRepository.findByNomMarque("iPhone 14pro");
		
		for (Marque m:marques)
			System.out.println(m);
	}
	

	@Test
	public void testFindMarqueByNomContains()
	{
		List<Marque> marques = marqueRepository.findByNomMarqueContains("P");
		
		for (Marque m:marques)
			System.out.println(m);
	}
	
	@Test
	public void testfindByNomPrix()
	{
	List<Marque> marques = marqueRepository.findByNomPrix("iPhone X", 1200.0);
	for (Marque m:marques)
	{
	System.out.println(m);
	}
	}
	
	@Test
	public void testfindByTelephone()
	{
	Telephone tel = new Telephone();
	tel.setIdTel(1L);
	
	List<Marque> marques = marqueRepository.findByTelephone(tel);
	for (Marque m : marques)
	{
	
		System.out.println(m);
	}
	}
	
	@Test
	public void findByCategorieIdCat()
	{
	List<Marque> marques = marqueRepository.findByTelephoneIdTel(1L);
	for (Marque m : marques)
	{
	System.out.println(m);
	}
	 }
	
	@Test
	public void testfindByOrderByNomMarqueAsc()
	{
	List<Marque> marques =
	marqueRepository.findByOrderByNomMarqueAsc();
	for (Marque m : marques)
	{
	System.out.println(m);
	}
	}
	
	@Test
	public void testTrierMarquesNomsPrix()
	{
	List<Marque> marques = marqueRepository.trierMarquesNomsPrix();
	for (Marque m : marques)
	{
	System.out.println(m);
	}
	}

	
	
	
}
	
	

