package com.example.demo.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Telephone {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long idTel;
	private String nomTel;
	private String descriptionTel;
	
	
	
	
	@OneToMany (mappedBy = "telephone")
	@JsonIgnore
	private List<Marque> marques;
	

	public Long getIdTel() {
		return idTel;
	}
	public void setIdTel(Long idTel) {
		this.idTel = idTel;
	}
	public String getNomTel() {
		return nomTel;
	}
	public void setNomTel(String nomTel) {
		this.nomTel = nomTel;
	}
	public String getDescriptionTel() {
		return descriptionTel;
	}
	public void setDescriptionTel(String descriptionTel) {
		this.descriptionTel = descriptionTel;
	}
	public List<Marque> getMarques() {
		return marques;
	}
	public void setMarques(List<Marque> marques) {
		this.marques = marques;
	}
	
	
	

}
