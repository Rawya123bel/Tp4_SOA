package com.example.demo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.example.demo.entities.Marque;
import com.example.demo.entities.Telephone;

@RepositoryRestResource(path = "rest")
public interface MarqueRepository extends JpaRepository<Marque, Long> {

	List<Marque> findByNomMarque(String nom);
	List<Marque> findByNomMarqueContains(String nom);
	
	/*@Query("select m from Marque m where m.nomMarque like %?1 and m.prixMarque > ?2")
	List<Marque> findByNomPrix (String nom, Double prix);
	*/ 
	@Query("select m from Marque m where m.nomMarque like %:nom and m.prixMarque > :prix")
	List<Marque> findByNomPrix (@Param("nom") String nom,@Param("prix") Double prix);


	@Query("select m from Marque m where m.telephone = ?1")
	List<Marque> findByTelephone (Telephone telephone);


	List<Marque> findByTelephoneIdTel(Long id);
	
	List<Marque> findByOrderByNomMarqueAsc();
	
	@Query("select m from Marque m order by m.nomMarque ASC, m.prixMarque ASC")
	List<Marque> trierMarquesNomsPrix ();
	
}
