package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.Marque;
import com.example.demo.entities.Telephone;

public interface MarqueService {
	Marque saveMarque(Marque m);
	Marque updateMarque(Marque m);
	void deleteMarque(Marque m);
	void deleteMarqueById(Long id);
	Marque getMarque(Long id);
	List<Marque> getAllMarques();
	List<Marque> findByNomMarque(String nom);
	List<Marque> findByNomMarqueContains(String nom);
	List<Marque> findByNomPrix (String nom, Double prix);
	List<Marque> findByTelephone (Telephone telephone);
	List<Marque> findByTelephoneIdTel(Long id);
	List<Marque> findByOrderByNomMarqueAsc();
	List<Marque> trierMarquesNomsPrix();

}
