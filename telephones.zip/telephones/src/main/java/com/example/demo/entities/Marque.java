package com.example.demo.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Marque {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long idMarque;
	private String nomMarque;
	private Double prixMarque;
	private Date dateCreation;
	
	@ManyToOne
	private Telephone telephone;
	
	public Marque() {
		super();
	}
	
	public Marque(String nomMarque, Double prixMarque, Date dateCreation) {
		super();
		this.nomMarque = nomMarque;
		this.prixMarque = prixMarque;
		this.dateCreation = dateCreation;
	}
	
	
	public Long getIdMarque() {
		return idMarque;
		}
	
	public void setIdMarque(Long idMarque) {
		this.idMarque = idMarque;
	}
	public String getNomMarque() {
		return nomMarque;
	}
	public void setNomMarque(String nomMarque) {
		this.nomMarque = nomMarque;
	}
	public Double getPrixMarque() {
		return prixMarque;
	}
	public void setPrixMarque(Double prixMarque) {
		this.prixMarque = prixMarque;
	}
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	@Override
	public String toString() {
		return "Marque [idMarque=" + idMarque + ", nomMarque=" + nomMarque + ", prixMarque=" + prixMarque
				+ ", dateCreation=" + dateCreation + "]";
	}

	public Telephone getTelephone() {
		return telephone;
	}

	public void setTelephone(Telephone telephone) {
		this.telephone = telephone;
	}
	
	
	

}
